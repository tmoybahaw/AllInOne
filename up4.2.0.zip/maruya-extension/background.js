// background.js
const UPDATE_CHECK_INTERVAL_MS = 60 * 60 * 1000; // 1 hour
const VERSION_JSON_URL = "https://play.salidaph.online/version.json"; // <-- host this file
const UPDATE_DOWNLOAD_URL = "https://play.salidaph.online/up.zip"; // <-- link to download/update page

// default on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get("openMode", data => {
    if (!data.openMode) chrome.storage.local.set({ openMode: "floating" });
  });

  // create context menu entries (right-click on action icon)
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "setFloating",
      title: "Set Mode: Floating Window",
      contexts: ["action"]
    });
    chrome.contextMenus.create({
      id: "setTab",
      title: "Set Mode: New Tab",
      contexts: ["action"]
    });
    chrome.contextMenus.create({
      id: "openPlayer",
      title: "Open Player Now",
      contexts: ["action"]
    });
  });

  // initial check
  checkForUpdate();
});

// When user clicks the extension icon
chrome.action.onClicked.addListener(() => {
  chrome.storage.local.get(["openMode"], ({ openMode }) => {
    if (openMode === "tab") {
      chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
    } else {
      chrome.windows.create({
        url: chrome.runtime.getURL("popup.html"),
        type: "popup",
        width: 1000,
        height: 700
      });
    }
  });
});

// Context menu click handler
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "setFloating") {
    chrome.storage.local.set({ openMode: "floating" }, () => {
      notify("Maruya", "Open mode set to Floating Window.");
    });
  } else if (info.menuItemId === "setTab") {
    chrome.storage.local.set({ openMode: "tab" }, () => {
      notify("Maruya", "Open mode set to New Tab.");
    });
  } else if (info.menuItemId === "openPlayer") {
    chrome.action.onClicked.dispatch(); // open player (fallback)
  }
});

// Notification helper
function notify(title, message, url) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/13.png",
    title,
    message
  }, (nid) => {
    if (url) {
      // open update page when user clicks the notification
      chrome.notifications.onClicked.addListener(function listener(clickedId) {
        if (clickedId === nid) {
          chrome.tabs.create({ url });
          chrome.notifications.onClicked.removeListener(listener);
        }
      });
    }
  });
}

// Auto-update check: fetch remote version.json and compare
async function checkForUpdate() {
  try {
    const res = await fetch(VERSION_JSON_URL, { cache: "no-store" });
    if (!res.ok) throw new Error("Update server returned " + res.status);
    const remote = await res.json(); // expected { "version": "4.2.0" }
    const localVersion = chrome.runtime.getManifest().version;
    if (remote.version && remote.version !== localVersion) {
      notify("Maruya Update", `Nice ang cute ko: ${remote.version}. Click to download.`, UPDATE_DOWNLOAD_URL);
    }
  } catch (err) {
    console.debug("Ay Pangit ka:", err);
  }
}

// periodic checks
setInterval(checkForUpdate, UPDATE_CHECK_INTERVAL_MS);
