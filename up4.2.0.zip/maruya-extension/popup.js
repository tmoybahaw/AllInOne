// popup.js
const API_KEY = "ba3885a53bc2c4f3c4b5bdc1237e69a0"; // <-- Replace with your TMDB API key
const IMAGE_BASE = "https://image.tmdb.org/t/p/w500";
const TMDB_BASE = "https://api.themoviedb.org/3";

const categoryTabs = document.getElementById("categoryTabs");
const recList = document.getElementById("recommendationList");
const player = document.getElementById("player");
const searchInput = document.getElementById("searchInput");
const nowWatchingEl = document.getElementById("nowWatching");
const matrixType = document.getElementById("matrixType");
const visitorCounter = document.getElementById("visitor-counter");
const typeMovieBtn = document.getElementById("typeMovie");
const typeTVBtn = document.getElementById("typeTV");
const openNewTabBtn = document.getElementById("openNewTabBtn");
const openWindowBtn = document.getElementById("openWindowBtn");

let currentType = "movie";
let currentCategoryIndex = 0;

const categories = [
  { id: "trending", label: "Trending" },
  { id: "popular", label: "Popular" },
  { id: "top_rated", label: "Top Rated" },
  { id: "upcoming", label: "Upcoming" },
  { id: "28", label: "Action" },
  { id: "16", label: "Animation" },
  { id: "10749", label: "Romance" },
  { id: "9648", label: "Mystery" },
  { id: "99", label: "Documentary" },
  { id: "878", label: "Sci-Fi" }
];

function setType(type) {
  currentType = type;
  if (type === "movie") {
    typeMovieBtn.classList.add("active");
    typeTVBtn.classList.remove("active");
  } else {
    typeTVBtn.classList.add("active");
    typeMovieBtn.classList.remove("active");
  }
  renderCategoryTabs();
  loadCategory(categories[0].id, 0);
}

typeMovieBtn.addEventListener("click", () => setType("movie"));
typeTVBtn.addEventListener("click", () => setType("tv"));

function renderCategoryTabs() {
  categoryTabs.innerHTML = "";
  categories.forEach((cat, idx) => {
    const btn = document.createElement("button");
    btn.textContent = cat.label;
    btn.onclick = () => loadCategory(cat.id, idx);
    if (idx === currentCategoryIndex) btn.classList.add("active");
    categoryTabs.appendChild(btn);
  });
}

async function loadCategory(catId, idx) {
  currentCategoryIndex = idx;
  document.querySelectorAll("#categoryTabs button").forEach((b, i) => b.classList.toggle("active", i === idx));
  recList.innerHTML = '<h2>Recommended</h2><div class="loading-spinner"></div>';
  let url;
  try {
    if (catId === "trending") {
      url = `${TMDB_BASE}/trending/${currentType}/week?api_key=${API_KEY}&language=en-US`;
    } else if (["popular","top_rated","upcoming"].includes(catId)) {
      if (currentType === "movie") url = `${TMDB_BASE}/movie/${catId}?api_key=${API_KEY}&language=en-US`;
      else {
        const tvEndpoint = catId === "upcoming" ? "popular" : catId;
        url = `${TMDB_BASE}/tv/${tvEndpoint}?api_key=${API_KEY}&language=en-US`;
      }
    } else {
      url = `${TMDB_BASE}/${currentType}/` + (currentType === "movie" ? "discover" : "discover") + `?api_key=${API_KEY}&language=en-US&with_genres=${catId}`;
      // For discover endpoints the path is the same; TMDB supports discover/movie and discover/tv
      url = `${TMDB_BASE}/discover/${currentType}?api_key=${API_KEY}&language=en-US&with_genres=${catId}`;
    }
    const res = await fetch(url);
    const data = await res.json();
    showRecommendations(data.results || []);
  } catch (err) {
    console.error("Category load failed", err);
    recList.innerHTML = '<h2>Recommended</h2><p style="color:red;text-align:center;">Failed to load recommendations.</p>';
  }
}

function showRecommendations(arr) {
  recList.innerHTML = "<h2>Recommended</h2>";
  if (!arr || arr.length === 0) {
    recList.innerHTML += '<p style="text-align:center;color:#A0A0A0;">No results found.</p>';
    return;
  }
  arr.forEach(item => {
    const title = item.title || item.name || "Untitled";
    const posterPath = item.backdrop_path || item.poster_path;
    const release = (item.release_date || item.first_air_date || "").split("-")[0] || "";
    const rating = (item.vote_average || 0).toFixed(1);
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <img src="${posterPath ? IMAGE_BASE + posterPath : 'https://via.placeholder.com/150x90.png?text=No+Image'}" alt="${title}">
      <div class="info">
        <div class="title">${title}</div>
        <div class="meta">⭐ ${rating} • ${release}</div>
      </div>
    `;
    card.onclick = () => {
      if (currentType === "movie") playMovie(item.id, title);
      else playTV(item.id, title);
    };
    recList.appendChild(card);
  });
  nowWatchingEl.textContent = `You are now watching: ${arr[0].title || arr[0].name}`;
}

function playMovie(id, title) {
  player.src = `https://player.videasy.net/movie/${id}`;
  nowWatchingEl.textContent = `Now watching: ${title}`;
  matrixType.textContent = `Playing movie ID: ${id}`;
}

function playTV(id, title) {
  // /tv/{id}/1/1?autoplayNextEpisode=true
  player.src = `https://player.videasy.net/tv/${id}/1/1?autoplayNextEpisode=true`;
  nowWatchingEl.textContent = `Now watching: ${title} (TV)`;
  matrixType.textContent = `Playing TV ID: ${id} — autoplay ON`;
}

let searchTimeout;
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(async () => {
    const q = searchInput.value.trim();
    if (q.length < 2) {
      loadCategory(categories[0].id, 0);
      return;
    }
    recList.innerHTML = '<h2>Recommended</h2><div class="loading-spinner"></div>';
    try {
      const res = await fetch(`${TMDB_BASE}/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(q)}&include_adult=false&language=en-US`);
      const data = await res.json();
      const results = data.results || [];
      recList.innerHTML = "<h2>Search Results</h2>";
      if (results.length === 0) {
        recList.innerHTML += '<p style="text-align:center;color:#A0A0A0;">No results.</p>';
        return;
      }
      results.forEach(item => {
        const mediaType = item.media_type || (item.first_air_date ? "tv" : "movie");
        const title = item.title || item.name || "Untitled";
        const posterPath = item.backdrop_path || item.poster_path;
        const rating = (item.vote_average || 0).toFixed(1);
        const release = (item.release_date || item.first_air_date || "").split("-")[0] || "";
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
          <img src="${posterPath ? IMAGE_BASE + posterPath : 'https://via.placeholder.com/150x90.png?text=No+Image'}" alt="${title}">
          <div class="info">
            <div class="title">${title}</div>
            <div class="meta">${mediaType.toUpperCase()} • ⭐ ${rating} • ${release}</div>
          </div>
        `;
        card.onclick = () => {
          if (mediaType === "tv") player.src = `https://player.videasy.net/tv/${item.id}/1/1?autoplayNextEpisode=true`;
          else player.src = `https://player.videasy.net/movie/${item.id}`;
          nowWatchingEl.textContent = `Now watching: ${title}`;
        };
        recList.appendChild(card);
      });
    } catch (err) {
      console.error("Search failed", err);
      recList.innerHTML = '<h2>Recommended</h2><p style="color:red;text-align:center;">Failed to perform search.</p>';
    }
  }, 450);
});

// visitor count fun
function loadVisitorCount() {
  visitorCounter.textContent = Math.floor(Math.random() * 5000) + 1;
}

// open controls (explicit)
openNewTabBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "open_tab" });
});
openWindowBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "open_window" });
});

// receive messages from background if needed
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.action === "open_in_tab") {
    window.open(chrome.runtime.getURL("popup.html"), "_blank");
  }
});

// initialize
renderCategoryTabs();
setType("movie");
loadVisitorCount();
