const modeInputs = document.querySelectorAll("input[name='mode']");

chrome.storage.local.get(["openMode"], ({ openMode }) => {
  modeInputs.forEach(input => {
    if (input.value === openMode) {
      input.checked = true;
    }
  });
});

modeInputs.forEach(input => {
  input.addEventListener("change", () => {
    chrome.storage.local.set({ openMode: input.value });
  });
});
